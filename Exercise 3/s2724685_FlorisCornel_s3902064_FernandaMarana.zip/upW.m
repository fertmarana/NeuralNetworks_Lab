function [newW] = upW(weights, deltaW)
    newW = weights + deltaW;
end