function [output] = output_function(x)
    % set output here
    output = sin(x);
end
