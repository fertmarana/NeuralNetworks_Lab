%this functions calculates the differential of the sigmoid of the output
function [output] = d_output_function_sin(x)
  output = cos(x);

end