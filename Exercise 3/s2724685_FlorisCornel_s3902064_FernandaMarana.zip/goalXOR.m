function [output] = goalXOR()
    output = [0; 1; 1; 0];
end