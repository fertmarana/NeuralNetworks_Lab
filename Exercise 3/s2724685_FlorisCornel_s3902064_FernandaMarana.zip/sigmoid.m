%this functions calculates the sigmoid
function [output] = sigmoid(x)
    % Define the sigmoid function here
    output = (1 ./(1+ exp(-x)));
end

