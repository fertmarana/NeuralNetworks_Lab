function [output] = goalNAND()
    output = [1; 1; 1; 0];
end