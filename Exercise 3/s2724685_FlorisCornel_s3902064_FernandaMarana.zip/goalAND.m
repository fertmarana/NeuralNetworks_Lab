function [output] = goalAND()
    output = [0; 0; 0; 1];
end