function [output] = identity_function_sin(x)
    output = 1./csc(x);
end